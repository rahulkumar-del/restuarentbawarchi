export const imageUrls = {
  hero: "/manus-storage/async-images/U555OnieBADkCmnQxWOWgg/image-1.webp",
  mutton: "/manus-storage/async-images/U555OnieBADkCmnQxWOWgg/image-2.webp",
  friedRice: "/manus-storage/async-images/U555OnieBADkCmnQxWOWgg/image-3.webp",
  noodles: "/manus-storage/async-images/U555OnieBADkCmnQxWOWgg/image-4.webp",
  family: "/manus-storage/async-images/U555OnieBADkCmnQxWOWgg/image-5.webp"
}

export const menuSeed = [
  { id: "mb-01", name: "Royal Mutton Biryani", category: "Mutton Biryani", description: "Slow-cooked mutton, saffron rice, fried onions and our signature dum masala.", price: 349, type: "Non-veg", bestseller: true, available: true, labels: ["House special"], image: imageUrls.mutton },
  { id: "mb-02", name: "Bawarchi Chicken Biryani", category: "Mutton Biryani", description: "Aromatic basmati, tender chicken and a bright mint-coriander finish.", price: 289, type: "Non-veg", bestseller: true, available: true, labels: ["Bestseller"], image: imageUrls.mutton },
  { id: "mb-03", name: "Dum Veg Biryani", category: "Mutton Biryani", description: "Seasonal vegetables, saffron and roasted cashews layered under fragrant rice.", price: 229, type: "Veg", bestseller: false, available: true, labels: ["Veg"], image: imageUrls.mutton },
  { id: "fr-01", name: "Smoky Chicken Fried Rice", category: "Fried Rice", description: "Wok-tossed rice, smoky chilli oil, spring onion and sesame crunch.", price: 219, type: "Non-veg", bestseller: true, available: true, labels: ["Wok-tossed"], image: imageUrls.friedRice },
  { id: "fr-02", name: "Classic Veg Fried Rice", category: "Fried Rice", description: "Crisp vegetables and fragrant rice finished with toasted garlic.", price: 179, type: "Veg", bestseller: false, available: true, labels: ["Veg"], image: imageUrls.friedRice },
  { id: "no-01", name: "Chilli Garlic Noodles", category: "Noodles", description: "Silky noodles, roasted garlic, peppers and a little late-night heat.", price: 199, type: "Veg", bestseller: true, available: true, labels: ["Spicy"], image: imageUrls.noodles },
  { id: "no-02", name: "Schezwan Chicken Noodles", category: "Noodles", description: "Wok-charred noodles with chicken, peppers and our schezwan glaze.", price: 239, type: "Non-veg", bestseller: false, available: false, labels: ["Coming back soon"], image: imageUrls.noodles }
]

export const offersSeed = [
  { id: "offer-01", title: "The Friends Feast", description: "One royal biryani, wok noodles, kebabs, raita and dessert for the whole table.", discount: 18, code: "FRIENDS18", validity: "Valid this month", image: imageUrls.family, active: true },
  { id: "offer-02", title: "Student Supper", description: "Show your student ID and unlock a warm, filling weekday meal.", discount: 12, code: "CAMPUS12", validity: "Mon–Thu · 4–7 PM", image: imageUrls.mutton, active: true },
  { id: "offer-03", title: "Biryani For Two", description: "Two mains, two coolers and a side of your choice.", discount: 15, code: "TABLE15", validity: "Weekends", image: imageUrls.mutton, active: true }
]

export const gallerySeed = [
  { id: "gallery-01", title: "Dum, done right", image: imageUrls.mutton, tag: "From the handi" },
  { id: "gallery-02", title: "Wok after dark", image: imageUrls.noodles, tag: "Late-night favourites" },
  { id: "gallery-03", title: "The table is ready", image: imageUrls.family, tag: "Bring your people" },
  { id: "gallery-04", title: "A little extra spice", image: imageUrls.friedRice, tag: "Always made fresh" }
]

export const ordersSeed = [
  { id: "FB-1048", customer: "Riya Sharma", phone: "+91 98765 43210", items: [{ name: "Royal Mutton Biryani", qty: 2 }], amount: 698, mode: "Takeaway", date: "Today, 7:42 PM", status: "Preparing" },
  { id: "FB-1047", customer: "Arjun Mehta", phone: "+91 99880 11220", items: [{ name: "Chilli Garlic Noodles", qty: 1 }, { name: "Classic Veg Fried Rice", qty: 1 }], amount: 378, mode: "Dine-in", date: "Today, 7:18 PM", status: "Accepted" },
  { id: "FB-1046", customer: "Nikhil Das", phone: "+91 90321 44310", items: [{ name: "Bawarchi Chicken Biryani", qty: 1 }], amount: 289, mode: "Takeaway", date: "Today, 6:54 PM", status: "Delivered" },
  { id: "FB-1045", customer: "Sara Khan", phone: "+91 97771 22990", items: [{ name: "The Friends Feast", qty: 1 }], amount: 899, mode: "Dine-in", date: "Today, 6:28 PM", status: "New" },
  { id: "FB-1044", customer: "Dev Patel", phone: "+91 91234 55770", items: [{ name: "Smoky Chicken Fried Rice", qty: 2 }], amount: 438, mode: "Takeaway", date: "Today, 5:51 PM", status: "Delivered" }
]

export const customersSeed = [
  { id: "cust-01", name: "Riya Sharma", phone: "+91 98765 43210", orders: 12, spend: 4680, lastOrder: "Today, 7:42 PM", favorite: "Royal Mutton Biryani" },
  { id: "cust-02", name: "Arjun Mehta", phone: "+91 99880 11220", orders: 8, spend: 2940, lastOrder: "Today, 7:18 PM", favorite: "Chilli Garlic Noodles" },
  { id: "cust-03", name: "Nikhil Das", phone: "+91 90321 44310", orders: 7, spend: 2399, lastOrder: "Today, 6:54 PM", favorite: "Bawarchi Chicken Biryani" },
  { id: "cust-04", name: "Sara Khan", phone: "+91 97771 22990", orders: 5, spend: 2180, lastOrder: "Today, 6:28 PM", favorite: "The Friends Feast" },
  { id: "cust-05", name: "Dev Patel", phone: "+91 91234 55770", orders: 4, spend: 1240, lastOrder: "Today, 5:51 PM", favorite: "Smoky Chicken Fried Rice" }
]

export const reviewsSeed = [
  { id: "review-01", name: "Ananya Rao", rating: 5, date: "2 hours ago", text: "The mutton was soft, the rice was fragrant and the portion was honestly generous.", visible: true },
  { id: "review-02", name: "Kabir Singh", rating: 4, date: "Yesterday", text: "Great student-friendly spot. The noodles have the perfect late-night kick.", visible: true },
  { id: "review-03", name: "Meera Kapoor", rating: 5, date: "3 days ago", text: "Lovely staff and the family combo made our table very happy.", visible: false }
]

export const defaultSettings = {
  phone: "+91 98765 00000",
  email: "hello@friendsbawarchi.in",
  address: "18 Spice Lane, Jubilee Hills, Hyderabad",
  hours: "Open daily · 11:30 AM – 11:00 PM",
  instagram: "@friendsbawarchi",
  homepageNote: "Dum-cooked. People-approved."
}

export const createInitialState = () => ({
  menu: menuSeed,
  offers: offersSeed,
  gallery: gallerySeed,
  orders: ordersSeed,
  customers: customersSeed,
  reviews: reviewsSeed,
  categories: ["Mutton Biryani", "Fried Rice", "Noodles"],
  history: [],
  settings: defaultSettings
})
